---
name: Report a problem in a theme
about: Use the following template if you want to report an issue with a theme
title: Add <theme> to the collection.
labels: bug

---

Describe the problem with the theme and attach a screenshot illustrating the
issue.
